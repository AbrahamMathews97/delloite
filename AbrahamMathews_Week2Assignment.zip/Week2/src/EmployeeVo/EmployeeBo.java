package EmployeeVo;

public class EmployeeBo {

	public void calincomeTax(EmployeeVo employee)
	{
		double annualincome=employee.getAnnualIncome();
		double incometax=(0.2*(annualincome));
		employee.setIncometax(incometax);
		System.out.println("Income tax computed for employee "+ employee.getEmpid()+" And Name:"+employee.getEmpname());
	}	
}
