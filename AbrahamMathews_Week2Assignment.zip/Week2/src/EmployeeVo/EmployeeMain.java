package EmployeeVo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.Iterator;


public class EmployeeMain {
    public static void main(String[] args) {

    	Scanner input=new Scanner(System.in);
    	System.out.println("Enter the Input size of Employees:");
         int number=input.nextInt();
         int id=0;
         double annualincome=0.0;
         String name=null;
         EmployeeVo employee[]=new EmployeeVo[number];
         
         for(int i=0;i<number;i++)
         {  System.out.println("For Customer "+(i+1));
         
        	employee[i]=new EmployeeVo(input.nextInt(),input.next(),input.nextDouble(),0);
         }
         
         for(int i=0;i<number;i++)
         {
        	 EmployeeBo employeeb=new EmployeeBo();
        	 employeeb.calincomeTax(employee[i]);
         }
         
         for(int i=0;i<number;i++)
         {
        	 System.out.println(employee[i]);
         }
         System.out.println("-------------------------------------------------------------");
         List<EmployeeVo> employeelist=new ArrayList<EmployeeVo>();
         for(int i=0;i<number;i++)
         {
        	 employeelist.add(employee[i]);
         }
         
         Collections.sort(employeelist,new Employeesort());
         Iterator<EmployeeVo> i=employeelist.iterator();

         System.out.println("-------------------------------------------------------------");
         while(i.hasNext())
         {   EmployeeVo employeevo=i.next();
        	 System.out.println(employeevo);
         }
         
	} 
}
