package EmployeeVo;

import java.util.Comparator;

public class Employeesort implements Comparator<EmployeeVo> {

	@Override
	public int compare(EmployeeVo c1, EmployeeVo c2) {
		// TODO Auto-generated method stub
		if(c1.getIncometax()>c2.getIncometax())
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

}
