package calculator;

import java.util.Scanner;

public class Add extends Arithematic{
	void read()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the first number:");
		this.num1=input.nextInt();
		System.out.println("Enter the second number:");
		this.num2=input.nextInt();
	}
	void display()
	{
		System.out.println("The addition of "+this.num1+" and "+this.num2+" is : "+this.result);
	}
	int calculate()
	{
		this.result=this.num1+this.num2;
		return this.result;
	}
}
