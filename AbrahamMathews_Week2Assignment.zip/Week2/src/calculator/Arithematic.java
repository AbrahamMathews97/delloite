package calculator;

abstract class Arithematic
	{
		int num1,num2;
		int result;
		
		abstract void read();
		abstract void display();
		abstract int calculate();
	}

