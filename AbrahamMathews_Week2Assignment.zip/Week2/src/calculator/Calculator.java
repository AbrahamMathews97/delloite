package calculator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Calculator{
	public static void main(String[] args) {
		Arithematic add=new Add();
		Arithematic sub=new subtract();
		Arithematic mult=new Mult();
		Arithematic divide=new Divide();
		
		List<Arithematic> objlist=new ArrayList<Arithematic>();
		objlist.add(add);
		objlist.add(sub);
		objlist.add(mult);
		objlist.add(divide);
		
		System.out.println("Enter your choice:");
		
		System.out.println("1.Addition");
		System.out.println("2.Subtraction");
		System.out.println("3.Multiplication");
		System.out.println("4.Division");
		
		Scanner input=new Scanner(System.in);
		int choice=input.nextInt();
		(objlist.get(choice-1)).read();
		(objlist.get(choice-1)).calculate();
		(objlist.get(choice-1)).display();
		
		
		
		
	}
}
