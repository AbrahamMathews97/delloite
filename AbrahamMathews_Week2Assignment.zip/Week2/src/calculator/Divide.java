package calculator;

import java.util.Scanner;

public class Divide extends Arithematic{
	void read()
	{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the first number:");
		this.num1=input.nextInt();
		System.out.println("Enter the second number:");
		this.num2=input.nextInt();
	}
	void display()
	{
		System.out.println("The division of "+this.num1+" and "+this.num2+" is : "+this.result);
	}
	int calculate()
	{
		if(num2==0)
		{
			System.out.println("Cannot divide by zero");
			return 0;
		}
		else 
		{
			this.result=(this.num1)/(this.num2);
			return this.result;
		}
	}
}
