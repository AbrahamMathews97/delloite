package com.cms.deloitte.client;

import java.util.Scanner;

import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;


public class LaunchCustomerApplication {
        public static void startcustomerApp()
        {
        	System.out.println("Welcome to the Customer App #####");
        	System.out.println("### 1. Add Customer #####");
        	System.out.println("#### 2.Update Customer ######");
        	System.out.println("#### Welcome to Customer App");
        	System.out.println("####### 6.Exit ########");
        	Scanner input=new Scanner(System.in);
        	System.out.println("Enter your choice:(1-6)");
        	int choice=input.nextInt();
        	//input.close();
        	if(choice==1)
        	{
        		Customer customer=new Customer();
        		customer.acceptCustomerDetails();
        		CustomerDAOImpl impl=new CustomerDAOImpl();
        		boolean result=impl.addCustomer(customer);
        	}
        	else if(choice==6)
        	{
        		System.out.println("Exiting the Program");
        		System.exit(0);
        	}
        }
}
