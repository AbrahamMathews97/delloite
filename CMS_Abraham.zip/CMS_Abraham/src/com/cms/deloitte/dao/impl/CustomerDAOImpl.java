package com.cms.deloitte.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.model.Customer;
import com.cms.deloitte.dbcon.*;

public class CustomerDAOImpl implements CustomerDAO{
   
    int result=0;
    private static final String INSERT_CUSTOMER_QUERY="insert into hr.customer values(?,?,?,?)";
    public boolean addCustomer(Customer customer){
    	try {
    	Connection connection=Databaseconnection.makeconnect();
    	PreparedStatement pstmt=
    			connection.prepareStatement(INSERT_CUSTOMER_QUERY);
    	
    	pstmt.setInt(1,customer.getCustomerid());
    	pstmt.setString(2,customer.getCustomerName());
    	pstmt.setString(3,customer.getCustomerAddress());
    	pstmt.setInt(4,customer.getBillAmount());
    	result=pstmt.executeUpdate();
    	}
    	catch(SQLException e) 
    	{
    		e.printStackTrace();
    	}
    	catch(ClassNotFoundException e1)
    	{
    		e1.printStackTrace();
    	}
    	if(result==0)
    	{return false;}
    	else
    	{return true;}
    	
    }
    
    @Override
    public Customer findCustomer(int customerid) {
    	return null;
    }@Override
    public boolean deleteCustomer(int delete_id) {
    	return false;
    }@Override
    public Customer isCustomerExists(int customerid) {
    	return null;
    }@Override
    public boolean updateCustomer(Customer customer) {
    	return false;
    }
    @Override
    public List<Customer> listCustomers() {
    	return null;
    }
}
