package Demo;
import java.lang.*;
import java.util.Scanner;
public class swap{
	int num1,num2;
  public void swapper()
  { 	Scanner input=new Scanner(System.in);
		num1=input.nextInt();
		num2=input.nextInt();
		int k=num2;
		num2=((num1+num2)+(num1-num2))/2;
		num1=((num1+k)-(num1-k))/2;
		System.out.println(num1+" "+num2);
  }
  public static void main(String[] args)
  {  swap s=new swap();
	 s.swapper();
  }
}
