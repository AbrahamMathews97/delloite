import finance.*;
public class Welcome {
	public static void main(String args[])
	{
		System.out.println("Welcome to Java");
		Bye b=new Bye();
		Apple a=new Apple();
		Ball ba=new Ball();
		System.out.println("\n-------------------------------\n");
		b.display2();
		a.display2();
		ba.display2();
		Salary s=new Salary();
		int result=s.calculateSalary(10,20);
		System.out.println("--------------------------------");
		System.out.println("\nThe Salary of the Employee is: "+result);
	}
}