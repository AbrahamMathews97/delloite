package oops;

public class Client {
   
	public static void main(String[] args)
	{
		Employee employee=new Employee();
		employee.takeSalary();
		employee.printEmployeeDetails();
		System.out.println("-------------------------------");
		employee.takeSalaryfromInput();
		System.out.println("-------------------------------");
		employee.printEmployeeDetails();
		System.out.println("-------------------------------");
	}
	
	
}
