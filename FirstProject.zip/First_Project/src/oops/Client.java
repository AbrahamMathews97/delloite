package oops;

public class Client {
   
	public static void main(String[] args)
	{
		/*Employee employee=new Employee();
		employee.takeSalary();
		employee.printEmployeeDetails();
		System.out.println("-------------------------------");
		System.out.println("Enter the Details to be stored :\n");
		employee.takeSalaryfromInput();
		System.out.println("-------------------------------");
		employee.printEmployeeDetails();
		System.out.println("-------------------------------");*/
		Customer customer=new Customer();
		customer.changeBillAmount(100);
		System.out.println("Bill Amount Changed To:"+customer.getBillAmount()+"\n-----------------------------------------------");
		customer.printCustomerDetails();
		customer.changeCustomerId(300);
		System.out.println("The customer Id is changed to :"+customer.getCustomerId()+"\n---------------------------------------");
		customer.printCustomerDetails();
		}
	
	
}
