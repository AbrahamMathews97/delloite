package oops;

public class Demo1 {

	int num=1000;
	public void display()
	{
		int num=100;
		System.out.println(num);
		System.out.println(this.num);
	}
	public void change()
	{
		num++;
	}
	public static void main(String args[])
	{
		Demo1 d1=new Demo1();
		Demo1 d2=new Demo1();
		d1.change();
		d1.display();
		d2.display();
	}
}
