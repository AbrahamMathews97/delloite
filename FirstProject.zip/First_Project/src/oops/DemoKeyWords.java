package oops;
import java.lang.StringBuffer;
public class DemoKeyWords {

	public static void main(String[] args)
	{
		/*for(String s:args) {
			System.out.print(s+",");
		}*/
		String name1="Tufail";
		String name2="Tufail";
		System.out.println(name1==name2);
		System.out.println(name1.equals(name2));
		
		StringBuffer sb=new StringBuffer("Kalp");
		System.out.println(sb);
		System.out.println(sb.length());
		System.out.println(sb.capacity());
	}
}
