package oops;

import java.util.StringTokenizer;
public class StringBufferDemo {
	public static void main(String[] args) 
	{
		String text="A QUICK BROWN FOX JUMPS OVER THE LAZY DOG AND KILLED IT";
		StringTokenizer tokenizer=new StringTokenizer(text);
		System.out.println(tokenizer.countTokens()+"\n");
		while(tokenizer.hasMoreTokens())
			{
				System.out.println(tokenizer.nextElement());
			}
		
	}
}
