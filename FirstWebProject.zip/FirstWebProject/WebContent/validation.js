function check()
{
 var username=document.getElementById("username").value;
 var password=document.getElementById("password").value;
 var cpassword=document.getElementById("cpassword").value;
 if(username.length==0)
	 {
	  alert("You have not entered the username\n Please Enter a username");
	  return false;
	 }
 else if(password.length==0)
	 {
	 alert("You have not entered the password\n Please Enter a password");
	 return false;
	 }
 else if(password.length<6)
	 {
	 alert("You have entered a password which is of less than 6 characters");
	 return false;}
 else if(password!=cpassword)
	 {
	   alert("Passwords do not match");
	   return false;
	 }
 else{
	 alert("Welcome " + username);
 	}
}

function checkuname()
{alert("Enter a good username");
}/**
 * 
 *//**
 * 
 */