package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

/**
 * Servlet implementation class Welcome2
 */
public class Welcome2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		int customerid=Integer.parseInt(req.getParameter("cust_id"));
		String customerName=req.getParameter("cust_name");
		String customerAddress=req.getParameter("cust_Addr");
		int billAmount=Integer.parseInt(req.getParameter("cust_bill_amount"));
		
		Customer customer=new Customer(customerid,customerName,customerAddress,billAmount);
		
		CustomerDAO impl=new CustomerDAOImpl();
		
		if(impl.isCustomerExists(customerid))
		{
			resp.getWriter().println(customerid+"already exists");
		}
		else
		{
			boolean result=impl.addCustomer(customer);
			resp.getWriter().println(customerName+" saved successfully" +result);
			System.out.println(customer.getCustomerid());
			System.out.println(customer.getCustomerName());
			System.out.println(customer.getCustomerAddress());
			System.out.println(customer.getBillAmount());
		}
			}

	}


