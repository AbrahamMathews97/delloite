package com.cms.deloitte.dao;
import java.util.List;

import com.cms.deloitte.model.Customer;

public interface CustomerDAO {
    
	public boolean addCustomer(Customer customer);
	public boolean updateCustomer(Customer customer);
	public boolean deleteCustomer(int delete_id);
	public List<Customer> listCustomers();
	public Customer findCustomer(int customerid);
	public boolean isCustomerExists(int customerid);
}



