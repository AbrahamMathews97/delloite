package com.cms.deloitte.dbcon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Databaseconnection {
    public static Connection makeconnect() throws SQLException,ClassNotFoundException{
  		Connection connection=null;
  	    Class.forName("oracle.jdbc.driver.OracleDriver");
  		
  		connection=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe","system","admin");
  		return connection;
    }
}


