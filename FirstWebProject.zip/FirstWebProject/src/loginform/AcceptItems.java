package loginform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AcceptItems
 */
public class AcceptItems extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AcceptItems() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String selectItems[]=request.getParameterValues("Item");
		System.out.println("The Items are:");
		if(selectItems==null)
		{
			response.getWriter().println("No Items are added");
		}
		else
		{
		response.getWriter().println("The Items are:");	
		for(String name:selectItems)
		{
			response.getWriter().println("<h1>"+name+"</h1>");
		}
		}
	}

}
