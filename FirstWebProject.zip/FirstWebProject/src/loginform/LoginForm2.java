package loginform;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthServlet
 */
public class LoginForm2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginForm2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("Username");
		//String password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		out.println("Authentication Successful!");
		
		Cookie allCookies[] = request.getCookies();
		boolean alrVisited = false;
		if(allCookies!=null) {
			for(Cookie c :allCookies) {
			if(c.getName().equals(userName)) {
				alrVisited = true;
				break;
			}
		}
		}
		out.println("<h1>Successfully authenticated");
		
		if(!alrVisited) {
			out.println("<h1>Welcome,you are the first time visitor , :"+userName+"</h1>");
			Cookie cookie = new Cookie(userName, userName);
			response.addCookie(cookie);
			System.out.println("Cookie Set");
		}else {
			out.println("Welcome,u have visited already");
		}
		
		out.println("<h1><form action='Welcome3'>");
		out.println("<h1>Wife Name:<input type='text' name='wifeName'>");
		out.println("<h1><input type='hidden' name='username' value="+userName);
		out.println("<h1><input type='submit' value='Enter'");
		out.println("<h1></form>");
}
}