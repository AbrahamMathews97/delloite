
public class Apple {
       public void display()
       {
    	   System.out.println("Hello World from Apple Display");
    	   Ball b=new Ball();
    	   b.display();
       }
       public void display2()
   	{
   		System.out.println("Hello World from Apple Display");
   	}
}
