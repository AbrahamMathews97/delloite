
public class Ball {
	public void display()
	{
		System.out.println("Hello World from Ball Display");
	}
	public void display2()
	{
		System.out.println("Hello World from Ball Display\n");
	}
}
