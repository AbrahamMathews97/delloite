
public class Bye {
	public void display()
	{
		System.out.println("Hello World from Bye Display");
		Apple a=new Apple();
		a.display();
	}
	public void display2()
	{
		System.out.println("Hello World from Bye Display");
	}
}
