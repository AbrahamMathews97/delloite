package Demo;
import java.util.Scanner;
public class Leap {
  int year;
  public boolean leap(int years)
  { if(years%4==0)
	  return true;
  else 
	  return false;
  }
  public static void main(String[] args)
  {
	  Leap l=new Leap();
	  Scanner input=new Scanner(System.in);
	  int year=input.nextInt();
	  if(l.leap(year)==true)
		  System.out.println("It is a Leap Year");
	  else
		  System.out.println("It is not a Leap Year");
  }
  
}
