package Exceptions;

import java.util.Scanner;
import java.lang.*;
import java.util.InputMismatchException;

public class Demo1 {

	public static void main(String[] args)
	{   int num1=0;
		int num2=0;
		int sum=0;
		System.out.println("Addition of two numbers");
		try
		{
			Scanner input=new Scanner(System.in);
			System.out.println("Enter the first number:\t");
			num1=input.nextInt();
			System.out.println("Enter the second number:\t");
			num2=input.nextInt();
			sum=num1/num2;
			input.close();
		}catch(ArithmeticException e)
		{
			System.out.println("Please enter the second number to be no equal to zero");
		}
		catch(InputMismatchException e1)
		{
			System.out.println("Please enter a correct number value and not an alphabet");
		}
		
		System.out.println("Sum is :"+sum);
	}
}
