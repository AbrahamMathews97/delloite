package Exceptions;

public class Demo3 {

	public void display() throws Exception
	{
		System.out.println("Welcome in Display");
		 Thread.sleep(1000);
		System.out.println("Bye");
	}
	
	public void display2() throws InterruptedException
	{
		System.out.println("Welcome in Display 2");
		Thread.sleep(1000);
		System.out.println("Bye");
	}
	
	public static void main(String args[]) throws Exception
	{
		System.out.println("Main called");
		Demo3 d=new Demo3();
		d.display();
		d.display2();
		System.out.println("Main Ended");
	}
}
