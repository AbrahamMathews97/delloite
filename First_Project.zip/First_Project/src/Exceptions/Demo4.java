package Exceptions;

import java.util.Scanner;

class validateAge extends RuntimeException
{
  public validateAge()
  {
	  
  }
 public validateAge(String msg)
 {
	 super(msg);
 }
	
}

class NewYearParty{
	int eligibleAge=16;
	Scanner input=new Scanner(System.in);
	int age;
	public void enterClub()
	{   
		System.out.println("Please enter your age:");
		age=input.nextInt();
		try {
		if(age<eligibleAge)
		{
			throw new validateAge("Age is restricted");
		}
		else
		{
			System.out.println("Age is validated and above 16");
			System.out.println("You can definitely enter the club");
		}
		}catch(validateAge a)
		{
			System.out.println("Age is restricted and shut the hell up");
		}
	}
}

public class Demo4 {
 public static void main(String args[])
 {
	 NewYearParty part=new NewYearParty();
	 part.enterClub();
 }
	
  
}
