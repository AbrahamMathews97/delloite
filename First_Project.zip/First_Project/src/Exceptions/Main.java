package Exceptions;

class Customer
{   public int id;
	public String name;
	public String location;
	public int billamount;
	public Customer(int id,String name,String location,int billamount)
	{
		this.id=id;
		this.name=name;
		this.location=location;
		this.billamount=billamount;
	}
	@Override
	public String toString()
	{
		return "[Customer has "+id+" with Customer Name "+name+" and location as "+location+" with bill amount as: "+billamount+"]\n";
	}
}



public class Main {
   public static void main(String[] args)
   {
	   Customer customer=new Customer(9671,"Geetanjali","Thrissur",97000);
	   Customer customer1=new Customer(9672,"Geethika","Hyderabad",10000);
	   System.out.println(customer);
	   System.out.println(customer1);
   }
}
