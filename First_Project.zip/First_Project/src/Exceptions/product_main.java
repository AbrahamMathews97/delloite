package Exceptions;

class product
{
	private int product_id;
	private String productName;
	private int qoh;
	private int price;
	
	public product(int id,String name,int qoh,int price){
		this.price=price;
		this.product_id=id;
		this.productName=name;
		this.qoh=qoh;
	}
	
	public int getid()
	{
		return this.product_id;
	}
	public void setid(int num)
	{
		this.product_id=num;
	}
	public String getname()
	{
		return this.productName;
	}
	public void setname(String name)
	{
		this.productName=name;
	}
	public int getqoh()
	{
		return this.qoh;
	}
	public void setqoh(int quantity)
	{
		this.qoh=quantity;
	}
	public int getprice()
	{
		return this.price;
	}
	public void setprice(int price)
	{
		this.price=price;
	}
	
	public String toString()
	{
		return "[Product has product id "+product_id+" with product name "+productName+" with quantity at hand as "+qoh+" and price as: "+price+"]\n";
	}
	
}

public class product_main {
   public static void main(String args[])
   {
	   product p=new product(100,"Soap",2,80);
	   product p2=new product(104,"Tea",5,180);   
	   product p3=new product(110,"Sugar",9,200);
	   System.out.println(p);;
	   System.out.println(p2);
	   System.out.println(p3);
   }
}
