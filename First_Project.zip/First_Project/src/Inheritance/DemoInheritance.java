package Inheritance;

interface Radio
{   
	int frequency=50;
	void start();
}

interface ModernRadio extends Radio
{
	void addbooster(int i);
}

class MusicPlayer implements ModernRadio
{
	@Override
	public void start()
	{
	 	System.out.println("\nRadio has started with frequency: "+frequency);
	}
	public void addbooster(int boosterf)
	{   
		System.out.println("\nRadio has started with an added booster frequency of "+(boosterf)+" is :"+(boosterf+frequency));
	}
	
}

interface ChangePass
{
	void doChange();
}
class ChangePassword
{
	String password="pass@123";
	class EncryptPassword
	{
		public void doEncrypt()
		{
			System.out.println("The password is:"+ password);
		}
	}
}
public class DemoInheritance {
	public static void main(String[] args) {
		MusicPlayer mp=new MusicPlayer();
		mp.start();
		mp.addbooster(100);
		System.out.print("\n");
		ChangePassword pa=new ChangePassword();
		ChangePassword.EncryptPassword e=pa.new EncryptPassword();
		e.doEncrypt();
		ChangePass c=new ChangePass()
		{//anonymous classes
			public void doChange()
			{
				System.out.println("Password has changed");
			}
		};

		System.out.print("\n");
		c.doChange();
	}
}
