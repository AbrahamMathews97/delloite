package Inheritance;

abstract class Animal
{
	public int picture;
	public int food;
	public int hunger;
	public int boundaries;
	public int location;
 public abstract void eat();	
	public void sleep()
  	{
  		System.out.println("Animal sleeps");
  	}
 public abstract void roam();
 public abstract void makeNoise();
}

abstract class Feline extends Animal
{
  	public void roam()
  	{
  		System.out.println("Feline Roams");
  	}
}

class Lion extends Feline
{
	public void makeNoise()
	{
		System.out.println("Lion roars");
	}
	public void eat()
	{
		System.out.println("Lion eats meat");
	}
}
class Tiger extends Feline
{ 
	public void makeNoise()
	{
		System.out.println("Tiger roars");
	}
	public void eat()
	{
		System.out.println("Tiger eats off-meat");
	}
}

class Cat extends Feline
{
	public void makeNoise()
	{
		System.out.println("Cat roars");
	}
	public void eat()
	{
		System.out.println("Cat drinks milk");
	}
}

class Hippo extends Animal
{
	public void makeNoise()
	{
		System.out.println("Hippo wails");
	}
	public void eat()
	{
		System.out.println("Hippo eats meat");
	}
	public void roam()
  	{
  		System.out.println("Hippo walks on water");
  	}
  	public void sleep()
  	{
  		System.out.println("Hippo sleeps with one eye open");
  	}
}

abstract class Canine extends Animal
{
	public void roam()
	{
		System.out.println("Canine roams");
	}
}

class Dog extends Canine
{
	public void makeNoise()
	{
		System.out.println("Dog Barks");
	}
	public void eat()
	{
		System.out.println("Dog eats dog treats");
	}
}

class Wolf extends Canine
{
	public void makeNoise()
	{
		System.out.println("Wolf howls");
	}
	public void eat()
	{
		System.out.println("Wolf eats meat");
	}
}

public class Inheritance
{
	public static void main(String[] args) {
		Animal a=new Lion();
		System.out.println("Lion:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
		System.out.println("\n---------------------------------------------------------------\n");
		a=new Tiger();
		System.out.println("Tiger:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
		System.out.println("\n---------------------------------------------------------------\n");
		a=new Cat();
		System.out.println("Cat:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
		System.out.println("\n---------------------------------------------------------------\n");
		a=new Wolf();
		System.out.println("Wolf:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
		System.out.println("\n---------------------------------------------------------------\n");
		a=new Dog();
		System.out.println("Dog:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
		System.out.println("\n---------------------------------------------------------------\n");
		a=new Hippo();
		System.out.println("Hippo:\n");
		a.eat();
		a.makeNoise();
		a.sleep();
		a.roam();
	}
}

