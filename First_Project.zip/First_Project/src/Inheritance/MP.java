package Inheritance;

interface MPPlayerName {
    default void start()
    {
    	System.out.println("Music Player has completely started");
    }
}

class TV implements MPPlayerName
{
   public void start()
   {
	   System.out.println("TV Started");
	   MPPlayerName.super.start();
   }
}

public class MP{
	 public static void main(String[] args)
	 {   TV tv=new TV();
	     tv.start();
	 }
}
