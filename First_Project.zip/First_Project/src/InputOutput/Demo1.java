package InputOutput;

import java.io.File;
import java.io.IOException;

public class Demo1 {
    
	public static void main(String[] args) throws IOException{
		File file=new File("C:\\Users\\Admin\\Desktop\\java\\Quiz.txt");
		if(file.exists())
		{
			System.out.println("Quiz.txt exists");
		}
		else
		{
			file.createNewFile();
			System.out.println("File Quiz.txt created");
		}
		System.out.println("Done");
	}
}
