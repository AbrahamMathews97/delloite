package InputOutput;

import java.io.File;

public class FileOutputStream {
    public static void main(String[] args) {
		File f=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\mohan.txt");
    	FileOutputStream outputstream=new FileOutputStream();
		
	}
}
