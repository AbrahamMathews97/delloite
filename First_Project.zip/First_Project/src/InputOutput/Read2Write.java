package InputOutput;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Read2Write{
   public static void main(String[] args) throws IOException{

	   File f1=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\inrecord.txt");
	   File f2=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\outrecord.txt");
	   f2.createNewFile();
	   FileReader reader=new FileReader(f1);
	   FileWriter writer=new FileWriter(f2);
	   int i=0;
	   while((i=reader.read())!=-1)
	   {
		   System.out.print((char)i);
		   writer.write(((char) i));
	   }
	   reader.close();
	   writer.close();
}
}
