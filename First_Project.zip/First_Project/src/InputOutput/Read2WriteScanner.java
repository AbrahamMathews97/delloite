package InputOutput;

import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Read2WriteScanner{
   public static void main(String[] args) throws IOException{
	   
	   System.out.println("Please enter the input file name:");
	   Scanner input=new Scanner(System.in);
	   String inputFile=input.nextLine();
	   
	   System.out.println("Please enter the output file name:");
	   String outputFile=input.nextLine();
	   
	   File f1=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\"+inputFile+".txt");
	   File f2=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\"+outputFile+".txt");
	   
	   f2.createNewFile();
	   
	   if(f1.exists()==true)
	   {
		   System.out.println("No Point in writing as file input.txt does not exist");
		   f1.delete();
		   f1.createNewFile();
	   }
	   
	   System.out.println("Enter the content for the input file:");
	   
	   String content=input.nextLine();
	   FileWriter input_writer=new FileWriter(f1);
	   
	   int j=0;
	   
	   while(j!=content.length())
	   {
		   input_writer.write(content.charAt(j));
		   j++;
	   }
	    input_writer.close();
	    
	    input.close();
	    
		FileReader reader=new FileReader(f1);
		FileWriter writer=new FileWriter(f2);
		
		int i=0;
		
		System.out.println("The Input file says:");
		while((i=reader.read())!=-1)
		{
			System.out.print((char)i);
			writer.write((char)i);
		}
		
		reader.close();
		writer.close();
	
	}

}
