package InputOutput;

import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class Read2WriteShortcut{
   public static void main (String[] args) throws IOException {
       String f1="C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\inrecord.txt";
	   String f2="C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\outrecord.txt";
	   
	   BufferedReader br=new BufferedReader(new FileReader(new File(f1)));
	   BufferedWriter bw=new BufferedWriter(new FileWriter(new File(f2)));
	   
	   int i=0;
	   while((i=br.read())!=-1)
	   {
		System.out.print((char)i);
		bw.write((char)i);
	    }
	   
	   br.close();
	   bw.close();
	   
}
}
