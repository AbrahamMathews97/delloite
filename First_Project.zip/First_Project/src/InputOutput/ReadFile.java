package InputOutput;

import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class ReadFile {
 public static void main(String[] args) throws IOException{
	File f=new File("C:\\Users\\Admin\\Desktop\\java\\First_Project\\src\\InputOutput\\mohan.txt");
    if(f.exists())
    {f.delete();}
    f.createNewFile();
	
    FileReader reader=new FileReader(f);
    int i=0;
    while((i=reader.read())!=-1)
    {
    	System.out.print((char)i);
    }
    FileWriter writer=new FileWriter(f);
    writer.append("Hey I am Mohan Again man.... I wrote this");
    writer.close();
    while((i=reader.read())!=-1)
    {
    	System.out.print((char)i);
    }
    reader.close();
}
}
