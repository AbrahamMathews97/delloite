package InputOutput;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.File;
import java.io.FileInputStream;

public class Serialization {
   public static void main(String[] args) throws IOException, ClassNotFoundException {
	//Serialisation
	   /*
	Customer customer=new Customer();
	customer.accept();
	ObjectOutputStream output_stream=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File("mohan1.txt"))));
    output_stream.writeObject(customer);
    output_stream.close();*/
	   
	//Deserialisation......
	   
    System.out.println("Data Done");
    ObjectInputStream input_stream=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("mohan1.txt"))));
    Customer customer1=new Customer();
    customer1=(Customer)input_stream.readObject();
    input_stream.close();
    System.out.println(customer1);
    
   }
}
