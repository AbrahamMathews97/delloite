package collections;

//import java.util.ArrayList;

import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
//import java.util.Map.Entry;

public class Demo {
      public static void main(String[] args)
      {
    	  /*
    	  List<String> names=new ArrayList<String>();
    	  names.add("Himanshu");
    	  names.add("Anthony");
    	  names.add("Swami");
    	  names.add(1,"Swami");
    	  //names.add(100);
    	  //names.add(true);
          names.add("Neha");
    	  Iterator<String> i=names.iterator();
    	  while(i.hasNext())
    	  {
    		  String str=i.next();
    		  if(str=="Neha")
    		   {
    			  continue;
    		   }
    		  System.out.println(str);
    	  }*/
    	  
    	  HashMap<Integer,String> Data=new HashMap<Integer,String>();
    	  Data.put(1098,"Velma");
    	  Data.put(2000,"Daphne");
    	  Data.put(2001,"Fred");
    	  
    	  Set set=Data.entrySet();
    	  
    	  Iterator i=set.iterator();
    	  
    	  while(i.hasNext())
    	  {
    		  Map.Entry me=(Map.Entry)i.next();
    		  System.out.print(me.getKey()+":");
    		  System.out.println(me.getValue());
    	  }
    	  System.out.println();
    	  
    	  String name=((String) Data.get(1098)).toString();
    	  Data.put(1098,new String("Velma2"));
    	  
    	  i=set.iterator();
    	  while(i.hasNext())
    	  {
    		  Map.Entry me=(Map.Entry)i.next();
    		  System.out.print(me.getKey()+":");
    		  System.out.println(me.getValue());
    	  }
   }
}
