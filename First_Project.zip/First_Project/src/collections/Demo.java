package collections;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class Demo {
      public static void main(String[] args)
      {
    	 /* TreeSet name=new TreeSet();
    	  name.add("Sumeet");
    	  name.add("Zeeshan");
    	  name.add("Abhishek");*/
    	  //System.out.println(name);
    	  
    	  List names=new ArrayList();
    	  if(names.isEmpty()==true)
    		  System.out.println("The list is empty");
    	  names.add("Himanshu");
    	  names.add("Anthony");
    	  names.add("Swami");
    	  names.add(1,"Swami");
    	  
    	  names.add(2,"Reddy");
    	  names.remove("Swami");
    	  names.remove("Swami");
    	  System.out.println(names);
    	  System.out.println(names.get(2));
    	  System.out.println(names.size());
    	  
    	  Set list=new LinkedHashSet();
    	  list.add("Himanshu");
    	  list.add("George");
    	  list.add("Hello");
    	  System.out.println(list);
      }
}
