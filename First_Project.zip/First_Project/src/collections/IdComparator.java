package collections;

import java.util.Comparator;

public class IdComparator implements Comparator<Customer> {

	@Override
	public int compare(Customer c1, Customer c2) {
		if(c1.getCustomerId()>c2.getCustomerId())
			{
			 return 0;
			}
		else
		{
			return -1;
		}
	}

}
