package collections;

import java.io.RandomAccessFile;
import java.io.IOException;


public class Randomfile {
     
	public static void main(String[] args) throws IOException {
		RandomAccessFile file=new RandomAccessFile("input","rw");
		file.writeUTF("Today is Friday");
        file.seek(0);

        long length=file.length();
        file.seek(length);
        file.writeUTF("Appended value");
        file.seek(0);
        String str=file.readLine();
        System.out.println("File input.txt content is:");
        System.out.println(str);
        file.close();
	}
	
}
