package collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

public class customer_demo {
        
	 public static void main(String[] args)
	 {   
		 List<Customer> allCustomers = new ArrayList<Customer>();
		 Customer customer1=new Customer(101,"John","Pune",60000);
		 
		 allCustomers.add(customer1);
		 allCustomers.add(new Customer(102,"Jeevan","Delhi",50000));
		 allCustomers.add(new Customer(201,"Kirti","Mumbai",30000));
		 allCustomers.add(new Customer(202,"Kriti","Hyderabad",20000));
		 
		 System.out.println("Sort on 1)Id 2)Name 3)Address 4)BillAmount:\t");
		 Scanner input=new Scanner(System.in);
		 int choice=input.nextInt();
		 input.close();
		 
		 if(choice==1)
		 {
			 Collections.sort(allCustomers,new IdComparator());
			 System.out.println("After sorting on Customer Id \n");
		 }
		 else if(choice==2)
		 {
			 Collections.sort(allCustomers,new NameComparator());
			 System.out.println("After sorting on Customer Name \n");
		 }
		 else if(choice==3)
		 {
			 Collections.sort(allCustomers,new Comparator<Customer>() {@Override
			public int compare(Customer c1, Customer c2) {
			   if(c1.getCustomerAddress().compareTo(c2.getCustomerAddress())>0)
			   {
				   return 0;
			   }
			   else
			   {
				   return -1;
			   }
			}
			});
			 System.out.println("After sorting on Customer Address \n");
			 
		 }
		 else if(choice==4)
		 {
			 Collections.sort(allCustomers);
			 System.out.println("After sorting on Customer Bill Amount \n");
		 }
		 
		 
		 Iterator<Customer> i=allCustomers.iterator();
		 try {
		 while(i.hasNext())
		 	{
			 Customer customer=i.next();
			 Thread.sleep(1000);
			 System.out.println(customer);
		 	}
		 }catch(InterruptedException e)
		 {
			 System.out.println("System can be interrupted using thread");
		 }
		 
		 System.out.println("*****************************************************************************Customers Displayed**************************************************************************************");
	 }
}
