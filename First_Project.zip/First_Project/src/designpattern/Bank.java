package designpattern;

public class Bank {
       public static void main(String[] args) {
		Payment payment=Payment.getPaymentObject();
		Payment payment2=Payment.getPaymentObject();
		Payment payment3=Payment.getPaymentObject();
		payment.pay(100);
		payment2.pay(2000);
		payment3.pay(500);
		
	}
}
