package finance;
import java.lang.*;

public class Salary {
   public int calculateSalary(int basic,int pf)
   {
	   return basic+pf;
   }
}
