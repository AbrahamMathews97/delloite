package jdbc_demo;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Scanner;

public class Customer implements Serializable,Comparator<Customer> {
       		/**
	 * 
	 */
	       private static final long serialVersionUID = 1L;
			private int customerId;
            private String customerName;
            private String customerAddress;
            private transient int billAmount;
            
       

        public void accept()
        {   
        	Scanner input=new Scanner(System.in);
        	System.out.println("Enter customer id:");customerId=input.nextInt();
        	System.out.println("Enter customer Name:");customerName=input.next();
        	System.out.println("Enter customer Address:");customerAddress=input.next();
        	System.out.println("Enter Bill Amount:");billAmount=input.nextInt();
        	input.close();
        }
        
        public int compare(Customer c1,Customer c2)
        {
        	if(c1.billAmount>c2.billAmount)
        	{
        		return 0;
        	}
        	else
        	{
        		return -1;
        	}
        }
        

		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public String getCustomerAddress() {
			return customerAddress;
		}

		public void setCustomerAddress(String customerAddress) {
			this.customerAddress = customerAddress;
		}

		public int getBillAmount() {
			return billAmount;
		}

		public void setBillAmount(int billAmount) {
			this.billAmount = billAmount;
		}

		@Override
		public String toString() {
			return "[Customer has Id=" + customerId + ", Name=" + customerName + ", Address="
					+ customerAddress + ", with Amount=" + billAmount + "]\n";
		}
        	
   
 }
