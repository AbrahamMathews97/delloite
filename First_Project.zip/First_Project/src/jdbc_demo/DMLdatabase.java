package jdbc_demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DMLdatabase {
      public static void main(String[] args) throws ClassNotFoundException, SQLException{
		Databaseconnection db=new Databaseconnection();
		Connection connect=db.makeconnect();
		Statement stmt=connect.createStatement();
		String query="delete from hr.customer where customerName='Duck'";
		int rowsAffected=stmt.executeUpdate(query);
		System.out.println("Rows affected succesfully:"+rowsAffected);
		
	}
}
