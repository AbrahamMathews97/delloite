package jdbc_demo;

import java.sql.DriverManager;
import java.util.Properties;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;


public class Database {
    public static void main(String[] args) throws ClassNotFoundException, SQLException,FileNotFoundException,IOException{
    	
    	FileReader reader=new FileReader("mydbproperties.properties");
    	Properties properties=new Properties();
    	
    	properties.load(reader);
    	
    	String driver=properties.getProperty("driver");
    	String url=properties.getProperty("url");
    	String username=properties.getProperty("username");
    	String password=properties.getProperty("password");
    	
    	
		Class.forName(driver);
		System.out.println("Driver Loaded");
		
		Connection connection=DriverManager.getConnection(url,username,password);
		System.out.println("Connected");
		
		Statement stmt=connection.createStatement();
		ResultSet rs=stmt.executeQuery("select customerName,customerAddress from hr.customer");
		
		while(rs.next())
		{
			System.out.print(rs.getString(1)+"\t");
            System.out.println(rs.getString(2));			
		}
		
	}
}
