package jdbc_demo;

import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Databaseconnection {
    public Connection makeconnect() throws SQLException,ClassNotFoundException{
  		Connection connection=null;
  	    Class.forName("oracle.jdbc.driver.OracleDriver");
  		System.out.println("Driver Loaded");
  		System.out.println("------------------------------------------------------------------------------------");
  		
  		connection=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe","system","admin");
  		System.out.println("Connected to Database Established");
  		System.out.println("------------------------------------------------------------------------------------");
  		return connection;
    }
}


