package jdbc_demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Object2Database {
          public static void main(String[] args) throws ClassNotFoundException,SQLException,IOException{
			Customer customer=new Customer();
			
			Databaseconnection db=new Databaseconnection();
			Connection connect=db.makeconnect();
			/*
			System.out.print("Enter the customer id we need to update:");
			Scanner input=new Scanner(System.in);
			int id=input.nextInt();
			input.close();*/
			System.out.println();
			/*PreparedStatement pstmt=connect.prepareStatement("update hr.customer set customerName=?,customerAddress=?,billAmount=? where customerid=?");
			
			System.out.println("Enter customer name: ");String name=input.next();
			System.out.println("Enter customer Address: ");String address=input.next();
			System.out.println("Enter bill amount: ");int bill=input.nextInt();
			
			
			pstmt.setInt(4,id);
			pstmt.setString(1, name);
			pstmt.setString(2, address);
			pstmt.setInt(3, bill);
			
			int row=pstmt.executeUpdate();
			System.out.println("Rows updated successfully:"+row);
			*/
			
			Statement stmt=connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=stmt.executeQuery("select hr.customer.* from hr.customer");
		    rs.moveToInsertRow();
		    rs.absolute(2);
		    
		    rs.updateInt("customerId",101);
		    rs.updateString("customerName", "Geetha");
		    rs.updateString("customerAddress", "Delhi");
		    rs.updateInt("billAmount",1000);
			rs.updateRow();
			
		    rs.beforeFirst();
		    
		    while(rs.next())
		    {
		    	System.out.print(rs.getInt(1)+"\t");
		    	System.out.print(rs.getString(2)+"\t");
		    	System.out.print(rs.getString(3)+"\t");
		    	System.out.println(rs.getInt(1)+"\t");
		    }
		    
			//pstmt.executeUpdate();
		    
			
			connect.close();
			
			
			
		}
}
