package jdbc_demo;

import java.sql.*;

public class createTable {
   public static void main(String[] args) throws ClassNotFoundException,SQLException {
	   Databaseconnection db=new Databaseconnection();
	   Connection connect=db.makeconnect();
	  /* Statement stmt=connect.createStatement();
	   
		ResultSet rs=stmt.executeQuery("select customerName,customerAddress from hr.customer");
		
		while(rs.next())
		{
			System.out.print(rs.getString(1)+"\t");
           System.out.println(rs.getString(2));			
		}*/
	   
	   Statement statement=connect.createStatement();
	   
	   //String query="create table hr.Salary_info(salary integer,bonus integer)";
	   String query1="drop table hr.salary_info";
	   
	   statement.execute(query1);
	   
	   System.out.println("Done");
}
}
