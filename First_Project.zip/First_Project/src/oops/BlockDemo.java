package oops;

public class BlockDemo {

	{
		System.out.println("Deloitte");//before constructor is called, this block is excecuted after every object is called..
	}
	static
	{
		System.out.println("Static method called"); //static method is called and then only main method is called.
	}
	
	public BlockDemo()
	{
		System.out.println("Constructor Called");
	}
	public static void main(String[] args)
	{
		System.out.println("Main Method called");
		new BlockDemo();
		new BlockDemo();
	}
}
