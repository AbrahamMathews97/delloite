package oops;

public class Customer {

	 private int customerId;
	   private String customerName;
	   private String customerAddress;
	   private int BillAmount=1000;
	
	public Customer()
	{
		customerId=101;
		customerName="Vishal";
		BillAmount=1000;
		customerAddress="Delhi";
	}
	   
	public Customer(int id,String Name,String Address,int Bill)
	{
		this.customerId=id;
		this.customerName=Name;
		this.BillAmount=Bill;
		this.customerAddress=Address;
	}
	
	public Customer(int customerId, String customerName) {
	    //default values of constructors
		this();
		this.customerId = customerId;
		this.customerName = customerName;
	}

	public void payBill()
	{
		System.out.println("Customer has paid the bill");
	}
	
	public void printCustomerDetails()
	{
		System.out.println("Customer Id: "+customerId);
		System.out.println("Customer Name: "+customerName);
		System.out.println("Customer Address: "+customerAddress);
		System.out.println("Customer Bill Amount: "+BillAmount);
		System.out.println("------------------------------------------");
	}
	//mutator
	public void changeBillAmount(int billAmount)
	{
		this.BillAmount=billAmount;
		System.out.println("Bill Amount changed");
		System.out.println("-------------------------------------------");
	}
	public void changeCustomerId(int custid)
	{
		this.customerId=custid;
		System.out.println("Customer Id changed");
		System.out.println("-------------------------------------------");
	}
	//getter
	public int getBillAmount()
	{
		return BillAmount;
	}
	public int getCustomerId()
	{ return customerId;
	}
}
