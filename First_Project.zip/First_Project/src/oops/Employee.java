
package oops;
import java.util.Scanner;
public class Employee {
	   
	   public int employeeId;
	   public String employeeName;
	   public String employeeAddress;
	   public int salary;
	   
	   public void takeSalary()
	   {
		   employeeId=101;
		   employeeName="Mohan";
		   employeeAddress="Coimbatore";
		   salary=45000;
	   }
	   public void takeSalaryfromInput()
	   {
		   Scanner input=new Scanner(System.in);
		   employeeId=input.nextInt();
		   employeeName=input.next();
		   employeeAddress=input.next();
		   salary=input.nextInt();
		   input.close();
	   }
	   
	   public void printEmployeeDetails()
	   {
		   System.out.println("Employee ID is : "+employeeId);
		   System.out.println("Employee Name is : "+employeeName);
		   System.out.println("Employee Address is : "+employeeAddress);
		   System.out.println("Employee Salary is : "+salary);
	   }
}


