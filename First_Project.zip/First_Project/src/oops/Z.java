package oops;

public class Z {
   W w=new W();
   {
	   System.out.println("Instance Block");
   }
   static 
   {
	   System.out.println("Static Block\n------------------");
   }
   public Z()
   {
	   System.out.println("Z constructor\n------------------");
   }
   
   public static void main(String[] args)
   {
	   System.out.println("In Main");
	   new Z();
	   new Z();
   }
}
