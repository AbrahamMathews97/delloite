package product_jdbc;

import java.util.Scanner;

public class Product
{
	private int product_id;
	private String productName;
	private int qoh;
	private int price;
	
	public void accept()
	{
		Scanner input1=new Scanner(System.in);
		System.out.println("Enter the product id:");
		this.product_id=input1.nextInt();
		
		System.out.println("Enter the product Name:");
		this.productName=input1.next();
		
		System.out.println("Enter the product price:");
		this.price=input1.nextInt();
		
		System.out.println("Enter the product price:");
		this.qoh=input1.nextInt();
		input1.close();
	}
	
	public void update_accept()
	{   Scanner input2=new Scanner(System.in);
		System.out.println("Updating values in product table");
		
		System.out.println("Enter the product id to be updated:");
		
		this.product_id=input2.nextInt();
		
		System.out.println("Enter the updated product Name:");
		this.productName=input2.next();
		
		System.out.println("Enter the updated product price:");
		this.price=input2.nextInt();
		
		System.out.println("Enter the updated product Quantity of Hand:");
		this.qoh=input2.nextInt();
		input2.close();
	}

	public int getid()
	{
		return this.product_id;
	}
	public void setid(int num)
	{
		this.product_id=num;
	}
	public String getname()
	{
		return this.productName;
	}
	public void setname(String name)
	{
		this.productName=name;
	}
	public int getqoh()
	{
		return this.qoh;
	}
	public void setqoh(int quantity)
	{
		this.qoh=quantity;
	}
	public int getprice()
	{
		return this.price;
	}
	public void setprice(int price)
	{
		this.price=price;
	}
	
	public String toString()
	{
		return "[Product has product id "+product_id+" with product name "+productName+" with quantity at hand as "+qoh+" and price as: "+price+"]\n";
	}
	
}