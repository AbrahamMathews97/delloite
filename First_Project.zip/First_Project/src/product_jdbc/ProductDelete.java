package product_jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductDelete {
      public static void main(String[] args) throws SQLException,ClassNotFoundException{
    	
    	  Scanner input=new Scanner(System.in);

  		Databaseconnection db=new Databaseconnection();
  		Connection connect=db.makeconnect();

  		Statement stmt=connect.createStatement();
  		
  		ResultSet rs=stmt.executeQuery("select * from hr.product");
		System.out.println("Old Database is:");
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}  
    	  
        System.out.println("Deleting records from table");
		
		System.out.println("Enter the product id to be deleted form table");
		int delete_id=input.nextInt();
		
		PreparedStatement pstmt1=connect.prepareStatement("delete from hr.product where productId=?");
		pstmt1.setInt(1, delete_id);
		
		int row1=pstmt1.executeUpdate();
		
		System.out.println("Rows updated successfully: "+row1);
		
        System.out.println("New Database is:");
		
		rs=stmt.executeQuery("select * from hr.product");
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}
		input.close();
		connect.close();
}
      }
