package product_jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductInsert {
    public static void main(String[] args) throws SQLException,ClassNotFoundException{
    	System.out.println("Inserting records into product table");
		Scanner input=new Scanner(System.in);

		Databaseconnection db=new Databaseconnection();
		Connection connect=db.makeconnect();

		Statement stmt=connect.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from hr.product");
		System.out.println("Old Database is:");
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}
		
		System.out.println("Enter the values to be inserted");
		
		//Declaring variables and accepting input from user
		Product product1=new Product();
		product1.accept();
		
		int id=product1.getid();
		String name=product1.getname();
		int price=product1.getprice();
		int qoh=product1.getprice();
		
		PreparedStatement pstmt=connect.prepareStatement("insert into hr.product values(?,?,?,?)");
		
		pstmt.setInt(1, id);
		pstmt.setString(2, name);
		pstmt.setInt(3, price);
		pstmt.setInt(4, qoh);
		
		int row=pstmt.executeUpdate();
		System.out.println("Rows updated successfully: "+row);
        
		System.out.println("New Database is:");
		
		rs=stmt.executeQuery("select * from hr.product");
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}
		
		System.out.println("-----------------------------------------------------------------------------------------------------------");
		input.close();
		connect.close();
	}
}
