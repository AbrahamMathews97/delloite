package product_jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProductShow {
   public static void main(String[] args) throws SQLException,ClassNotFoundException {
		System.out.println("Printing all the records from product table");
		
		Databaseconnection db=new Databaseconnection();
		Connection connect=db.makeconnect();
		
		
		Statement stmt=connect.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from hr.product");
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}
		connect.close();
}
}
