package product_jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductUpdate {
   public static void main(String[] args) throws SQLException,ClassNotFoundException{
	 

	  	Databaseconnection db=new Databaseconnection();
	  	Connection connect=db.makeconnect();

	  	Statement stmt=connect.createStatement();
	  		
	  	ResultSet rs=stmt.executeQuery("select * from hr.product");
	  	System.out.println("Old Database is:");	 
	  	 rs=stmt.executeQuery("select * from hr.product");
			
			while(rs.next())
			{
				System.out.print(rs.getInt(1)+"\t");
				System.out.print(rs.getString(2)+"\t");
				System.out.print(rs.getInt(3)+"\t");
				System.out.println(rs.getInt(4)+"\t");
			}
		
	  	
	    Product product2=new Product();
	  	product2.update_accept();
	  		
	  	Scanner input=new Scanner(System.in);	
		
		int update_id=product2.getid();
		String update_name=product2.getname();
		int update_price=product2.getprice();
		int update_qoh=product2.getqoh();
		
		
		PreparedStatement pstmt2=connect.prepareStatement("update hr.product set productName=?,price=?,qoh=? where productid=?");
		
		pstmt2.setInt(4, update_id);
		pstmt2.setString(1, update_name);
		pstmt2.setInt(2, update_price);
		pstmt2.setInt(3, update_qoh);
		
		int row2=pstmt2.executeUpdate();
		
		System.out.println("Rows Updated Successfully: "+row2);
		
		System.out.println("New Database is:");
		
        rs=stmt.executeQuery("select * from hr.product");
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t");
			System.out.print(rs.getInt(3)+"\t");
			System.out.println(rs.getInt(4)+"\t");
		}
		
		System.out.println("-----------------------------------------------------------------------------------------------------------");
		input.close();
		connect.close();
}
}
