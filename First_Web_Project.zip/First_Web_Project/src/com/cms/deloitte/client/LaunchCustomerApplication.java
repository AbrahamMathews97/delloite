package com.cms.deloitte.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;


public class LaunchCustomerApplication {
        public static void startcustomerApp()
        {       
        	System.out.println("Welcome to the Customer App #####");
        	System.out.println("#### 1. Add Customer #####");
        	System.out.println("#### 2.Update Customer ######");
        	System.out.println("#### 3.Delete Customer ####");
        	System.out.println("#### 4.Fetch Customer ####");
        	System.out.println("#### 5.Fetch All Customers ####");
        	System.out.println("####### 6.Exit ########");
     
        	Scanner input=new Scanner(System.in);
        	System.out.println("Enter your choice:(1-6)");
        	
        	int choice=input.nextInt();
        	
        	Customer customer=new Customer();
        	CustomerDAO impl=new CustomerDAOImpl();
        	boolean result;
    
        	List<Customer> clist=new ArrayList<Customer>();
        	if(choice==1)
        	{   customer.acceptCustomerDetails();
        		if(impl.isCustomerExists(customer.getCustomerid())==false)
        		 {result=impl.addCustomer(customer);
                  System.out.println("The customer details are added"); 
        		 }
        		else
        		{
        			System.out.println(customer.getCustomerid()+"already exists");
          		  
        		}
        	    
        	}
        	else if(choice==2)
        	{   System.out.println("Enter the Customer ID to be updated:");
        		int update_id=input.nextInt();
        		if(impl.isCustomerExists(update_id))
        		{
        			customer=impl.findCustomer(update_id);
        		    result=impl.updateCustomer(customer);
        		}
        		else
        		{
        			System.out.println("The id does not exist");
        		}
        	}
        	else if(choice==3)
        	{
        		System.out.println("Enter the Customer Id to be deleted:");
        		int delete_id=input.nextInt();
        		if(impl.isCustomerExists(delete_id)==true)
        		{
        			customer=impl.findCustomer(delete_id);
        			result=impl.deleteCustomer(delete_id);
        		}
        		else
        		{
        			System.out.println("The id does not exist");
        		}
        	}
        	else if(choice==4)
        	{
        		System.out.println("Enter the customer id to be entered:");
        		int fetch_id=input.nextInt();
        		if(impl.isCustomerExists(fetch_id))
        		{
        			customer=impl.findCustomer(fetch_id);
        			System.out.println(customer);
        		}
        		else
        		{
        			System.out.println("Customer with "+fetch_id+"does not exist");
        		}
        	}
        	else if(choice==5)
        	{
        		System.out.println("The Customers are:");
        		clist=impl.listCustomers();
        		Iterator<Customer> i=clist.iterator();
        		while(i.hasNext())
        		{
        			System.out.println(i.next());
        		}
        	}
        	else if(choice==6)
        	{
        		System.out.println("Exiting the Program");
        		System.exit(0);
        	}
	
            }
        }


