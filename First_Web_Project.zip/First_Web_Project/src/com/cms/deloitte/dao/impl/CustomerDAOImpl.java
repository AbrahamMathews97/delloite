package com.cms.deloitte.dao.impl;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.model.Customer;
import com.cms.deloitte.dbcon.*;

public class CustomerDAOImpl implements CustomerDAO{
   
    int result=0;
    private static final String INSERT_CUSTOMER_QUERY="insert into hr.customer values(?,?,?,?)";
    private static final String UPDATE_CUSTOMER_QUERY="update hr.customer set customerName=?,customerAddress=?,billAmount=? where customerId=?";
    private static final String DELETE_CUSTOMER_QUERY="delete from hr.customer where customerId=?";
    private static final String FETCH_CUSTOMER_QUERY="select * from hr.customer where customerId=?";
    private static final String ALL_CUSTOMERS="select * from hr.customer";
    
    public boolean addCustomer(Customer customer){
    	try {
    	Connection connection=Databaseconnection.makeconnect();
    	PreparedStatement pstmt=
    			connection.prepareStatement(INSERT_CUSTOMER_QUERY);
    	
    	pstmt.setInt(1,customer.getCustomerid());
    	pstmt.setString(2,customer.getCustomerName());
    	pstmt.setString(3,customer.getCustomerAddress());
    	pstmt.setInt(4,customer.getBillAmount());
    	result=pstmt.executeUpdate();
    	}
    	catch(SQLException e) 
    	{
    		e.printStackTrace();
    	}
    	catch(ClassNotFoundException e1)
    	{
    		e1.printStackTrace();
    	}
    	if(result==0)
    	{return false;}
    	else
    	{return true;}
    	
    }
    
    @Override
    public Customer findCustomer(int customerid) {
    	ResultSet rs=null;      
    	Customer customer=new Customer();
    	try {
     	Connection connection=Databaseconnection.makeconnect();
    	PreparedStatement pstmt3=
    			connection.prepareStatement(FETCH_CUSTOMER_QUERY);
    	pstmt3.setInt(1,customerid);
    	rs=pstmt3.executeQuery();
    	while(rs.next()) {
    	customer.setCustomerid(rs.getInt(1));
    	customer.setCustomerName(rs.getString(2));
    	customer.setCustomerAddress(rs.getString(3));
    	customer.setBillAmount(rs.getInt(4));
    	return customer;
    	}
    	}catch(SQLException e)
    	{
    		e.printStackTrace();
    	}catch(ClassNotFoundException e1)
    	{
    		e1.printStackTrace();
    	}
       return customer;	
    }
    
    @Override
    public boolean deleteCustomer(int delete_id) {
    	try {
        	Connection connection=Databaseconnection.makeconnect();
        	PreparedStatement pstmt2=
        			connection.prepareStatement(DELETE_CUSTOMER_QUERY);
        	
        	pstmt2.setInt(1,delete_id);
        	
        	result=pstmt2.executeUpdate();
        	}
        	catch(SQLException e) 
        	{
        		e.printStackTrace();
        	}
        	catch(ClassNotFoundException e1)
        	{
        		e1.printStackTrace();
        	}
        	if(result==0)
        	{return false;
        	}
        	else
        	{return true;
        	}
      
       }
    @Override
    public boolean isCustomerExists(int customerid) {
        ResultSet rs=null;      
    	try {
     	Connection connection=Databaseconnection.makeconnect();
    	PreparedStatement pstmt3=
    			connection.prepareStatement(FETCH_CUSTOMER_QUERY);
    	pstmt3.setInt(1,customerid);
    	rs=pstmt3.executeQuery();
    	
    	}catch(SQLException e)
    	{
    		e.printStackTrace();
    	}catch(ClassNotFoundException e1)
    	{
    		e1.printStackTrace();
    	}
    	if(rs!=null)
    	{
    		return true;
    	}
    	else
    	{
    	return false;
    	}
    	}
    @Override
    public boolean updateCustomer(Customer customer) {
    	try {
        	Connection connection=Databaseconnection.makeconnect();
        	PreparedStatement pstmt1=
        			connection.prepareStatement(UPDATE_CUSTOMER_QUERY);
        	customer.updateCustomerDetails();
        	
        	pstmt1.setInt(4,customer.getCustomerid());
        	pstmt1.setString(1,customer.getCustomerName());
        	pstmt1.setString(2,customer.getCustomerAddress());
        	pstmt1.setInt(3,customer.getBillAmount());
        	
        	result=pstmt1.executeUpdate();
        	}
        	catch(SQLException e) 
        	{
        		e.printStackTrace();
        	}
        	catch(ClassNotFoundException e1)
        	{
        		e1.printStackTrace();
        	}
        	if(result==0)
        	{return false;}
        	else
        	{return true;}
        	
        }
    
    @Override
    public List<Customer> listCustomers() {
    	List<Customer> clist=new ArrayList<Customer>();
    	try {
    	Connection connection=Databaseconnection.makeconnect();
    	Statement stmt=connection.createStatement();
    	
    	ResultSet rs=stmt.executeQuery(ALL_CUSTOMERS);
    	while(rs.next())
    	{
    	  	Customer customer=new Customer();
    	  	customer.setCustomerid(rs.getInt(1));
    	  	customer.setCustomerName(rs.getString(2));
    	  	customer.setCustomerAddress(rs.getString(3));
    	  	customer.setBillAmount(rs.getInt(4));
    	  	clist.add(customer);
    	}
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	catch(ClassNotFoundException e1)
    	{
    		e1.printStackTrace();
    	}
    	return clist;
    }
}
