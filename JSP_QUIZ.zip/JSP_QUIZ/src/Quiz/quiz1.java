package Quiz;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class quiz1
 */
public class quiz1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public quiz1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        

		response.getWriter().println("<form action='quiz12' method:'get'>");
		response.getWriter().println("<pre> 1)Anwar had three chocolates, Ashwin had five chocolates. "
				+ "If there are ten in total, How much did Lakshmi have? ");
		response.getWriter().println("a)Three<input type='radio' value='a' name='quiz1'>");
		response.getWriter().println("b)Two<input type='radio' value='b' name='quiz1'>");
		response.getWriter().println("c)Ten<input type='radio' value='c' name='quiz1'>");
		response.getWriter().println("<input type='submit' value='Next Question'></pre>");
		response.getWriter().println("</form>"); 
	
	}

	

}
