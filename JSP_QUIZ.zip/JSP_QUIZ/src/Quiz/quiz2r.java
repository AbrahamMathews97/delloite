package Quiz;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class quiz2r
 */
public class quiz2r extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public quiz2r() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stubString quiz1=request.getParameter("quiz1");		
		String quiz2=request.getParameter("quiz2");
		HttpSession session=request.getSession();
		session.setAttribute("quiz2",quiz2);
		session.setAttribute("answer2","b");
		 
		RequestDispatcher dispatcher=request.getRequestDispatcher("Results.jsp");
		dispatcher.forward(request, response);
	}

	
}
