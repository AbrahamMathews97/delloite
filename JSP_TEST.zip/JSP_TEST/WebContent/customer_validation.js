

function check()
{  //Values for the HTML page 
	var id=document.getElementById("cust_id").value;
	var name=document.getElementById("cust_name").value;
	var addr=document.getElementById("cust_Addr").value;
	var bill=document.getElementById("cust_bill_amount").value;
   //error Message values
	var errorMessageId=document.getElementById("errorMessageCustomerId");
	var errorMessageName=document.getElementById("errorMessageCustomerName");
	var errorMessageAddr=document.getElementById("errorMessageCustomerAddress");
	var errorMessagebill=document.getElementById("errorMessageCustomerBillAmount");
   //validate messages
	var validate=document.getElementById("Congratulations");
	var validate_id=document.getElementById("customer_id");
	var validate_name=document.getElementById("customer_name");
	var validate_address=document.getElementById("customer_address");
	var validate_bill=document.getElementById("bill_amount");
	
	if(id.length==5)
		{
		 errorMessageId.innerHTML=" ";
		 validate.innerHTML=" ";
		 validate_id.innerHTML=" ";
		 validate_name.innerHTML=" ";
		 validate_address.innerHTML=" ";
		 validate_bill.innerHTML=" ";
		}
	else
		{
		errorMessageId.innerHTML="<font color=red>Please enter customer id with 5 characters</font>";		
		return false;
		}
    if(addr=='Pune' || addr=='Delhi' || addr=='Mumbai')
    	{
    	 errorMessageAddr.innerHTML=" ";
    	 validate.innerHTML=" ";
 		 validate_id.innerHTML=" ";
 		 validate_name.innerHTML=" ";
 		 validate_address.innerHTML=" ";
 		 validate_bill.innerHTML=" ";
 		
    	}
    else
    	{
    	errorMessageAddr.innerHTML="<font color=red>Please enter address which is either Pune,Delhi or Mumbai</font>";
    	return false;
    	}
    if(bill>0)
    	{
    	 errorMessagebill.innerHTML=" ";
    	 validate.innerHTML=" ";
 		 validate_id.innerHTML=" ";
 		 validate_name.innerHTML=" ";
 		 validate_address.innerHTML=" ";
 		 validate_bill.innerHTML=" ";
 		
    	}
    else
    	{
    	errorMessagebill.innerHTML="<font color=red>Please enter the bill amount greater than zero</font>";
    	return false;
    	}

}

function validated()
{   //value division
	var id=document.getElementById("cust_id").value;
	var name=document.getElementById("cust_name").value;
	var addr=document.getElementById("cust_Addr").value;
	var bill=document.getElementById("cust_bill_amount").value;
	//validated message ID values
	var validate_id=document.getElementById("customer_id");
	var validate_name=document.getElementById("customer_name");
	var validate_address=document.getElementById("customer_address");
	var validate_bill=document.getElementById("bill_amount");
	//validate message
	var validate=document.getElementById("Congratulations");
	validate.innerHTML="<h2><font color=blue>Your customer details are successfully updated:</font><h2>";
	validate_id.innerHTML="<h2><font color=blue>Your customer ID is:  "+id+"</font><h2>";
	validate_name.innerHTML="<h2><font color=blue>Your customer Name is:  "+name+"</font><h2>";
	validate_address.innerHTML="<h2><font color=blue>Your customer Address is:  "+addr+"</font><h2>";
	validate_bill.innerHTML="<h2><font color=blue>Your customer Bill is:  "+bill+"</font><h2>";

}

/**
 * 
 */