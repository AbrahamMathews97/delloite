package com.deloitte;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class AddressTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();

		try {
			out.println("<h1>Deloitte</h1><br/>");
			out.println("<h1>Block C</h1><br/><h1>Divyasree Technopolis</h1><br/>");
			out.println("<h1>Survey No: 123 & 132/2</h1><br/>");
			out.println("<h1>Yemlur Post</h1><br/>");
			out.println("<h1>Off Old Airport Road</h1><br/>");
			out.println("<h1>Karnataka 560037</h1><br/>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.doStartTag();
	}
}