package com.deloitte;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class NameTag extends TagSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private String nameToPrint;
    
    public void setNameToPrint(String name)
    {
    	this.nameToPrint=name;
    }
    
    public String getNameToPrint()
    {
    	return nameToPrint;
    }
	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();

		try {
			for(int i=0;i<10;i++)
			{
				out.println("<h1>"+nameToPrint+"</h1>");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.doStartTag();
	}
}
